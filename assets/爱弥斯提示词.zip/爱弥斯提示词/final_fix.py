# -*- coding: utf-8 -*-
"""最终修复: ①全部GIF基线(底部)对齐 ②work边缘环切 ③left peek移除封闭大白块"""
import sys, os, glob
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

GIFDIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"
EDGE_TRIM = {"work.gif": (10, 10, 4, 4)}   # 左,右,上,下 (px)
BLOB_REMOVE = {"left peek.gif": 1000}       # 封闭白色连通域采样点阈值

def load_frames(path):
    im = Image.open(path)
    frames = []
    for i in range(im.n_frames):
        im.seek(i)
        frames.append(im.convert("RGBA").copy())
    return frames, im.info.get("duration", 250)

def save_gif(frames, path, dur):
    ap = [S.to_gif_frame(f) for f in frames]
    tr = ap[0].info["transparency"]
    ap[0].save(path, save_all=True, append_images=ap[1:],
               duration=dur, loop=0, disposal=2, transparency=tr, optimize=False)
    print(f"  已保存 {os.path.basename(path)}: {len(ap)} 帧, {dur}ms")

def remove_enclosed_white_blobs(frames, thr):
    """移除封闭(不触边)的大块不透明白色区域(源图异物), 保留小白色部件(头饰/高光)"""
    out = []
    for fi, f in enumerate(frames):
        w, h = f.size
        a = f.getchannel("A")
        px = f.load()
        white_pts = set()
        for y in range(0, h, 2):
            for x in range(0, w, 2):
                if a.getpixel((x, y)) > 100:
                    r, g, b, _ = px[x, y]
                    if r > 235 and g > 235 and b > 235:
                        white_pts.add((x, y))
        seen = set()
        removed = 0
        for p in white_pts:
            if p in seen:
                continue
            stack = [p]; comp = []
            while stack:
                q = stack.pop()
                if q in seen: continue
                seen.add(q); comp.append(q)
                qx, qy = q
                for dx in (-2, 0, 2):
                    for dy in (-2, 0, 2):
                        nq = (qx+dx, qy+dy)
                        if nq in white_pts and nq not in seen:
                            stack.append(nq)
            if len(comp) >= thr:
                # 是否接触边缘
                touches = (min(c[0] for c in comp) <= 4 or max(c[0] for c in comp) >= w-5 or
                           min(c[1] for c in comp) <= 4 or max(c[1] for c in comp) >= h-5)
                if not touches:
                    # 移除: 该连通域所有点(及其附近)变透明
                    for qx, qy in comp:
                        for dx in (-1, 0, 1):
                            for dy in (-1, 0, 1):
                                X, Y = qx*2+dx, qy*2+dy
                                if 0 <= X < w and 0 <= Y < h:
                                    px[X, Y] = (255, 255, 255, 0)
                    removed += 1
        if removed:
            print(f"  帧{fi+1}: 移除 {removed} 个封闭白色大块")
        out.append(f)
    return out

for gpath in sorted(glob.glob(os.path.join(GIFDIR, "*.gif"))):
    name = os.path.basename(gpath)
    frames, dur = load_frames(gpath)
    print(f"===== {name} =====")

    # ③ left peek: 移除封闭大白块
    if name in BLOB_REMOVE:
        frames = remove_enclosed_white_blobs(frames, BLOB_REMOVE[name])

    # ② work: 边缘环切(只动边缘)
    if name in EDGE_TRIM:
        l, r, t, b = EDGE_TRIM[name]
        frames2 = []
        for f in frames:
            w, h = f.size
            px = f.load()
            for y in range(h):
                for x in range(l):
                    px[x, y] = (255, 255, 255, 0)
                for x in range(w-r, w):
                    px[x, y] = (255, 255, 255, 0)
            for x in range(w):
                for y in range(t):
                    px[x, y] = (255, 255, 255, 0)
                for y in range(h-b, h):
                    px[x, y] = (255, 255, 255, 0)
            frames2.append(f)
        frames = frames2
        print(f"  已环切边缘 左{l} 右{r} 上{t} 下{b}px")

    # ① 基线(底部)对齐: 所有帧内容底部对齐到同一水平线
    bboxes = [f.getchannel("A").getbbox() for f in frames]
    bottoms = [b[3] for b in bboxes if b]
    baseline = max(bottoms)
    shifts = [(baseline - b[3]) if b else 0 for b in bboxes]
    max_shift = max(shifts)
    W = max(f.width for f in frames)
    H = max(f.height + s for f, s in zip(frames, shifts))
    aligned = []
    for f, s in zip(frames, shifts):
        c = Image.new("RGBA", (W, H), (255, 255, 255, 0))
        c.paste(f, (0, s), f)
        aligned.append(c)
    print(f"  基线对齐: baseline={baseline}, 最大下移={max_shift}, 画布 {W}x{H}")

    save_gif(aligned, gpath, dur)
