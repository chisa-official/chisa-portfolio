# -*- coding: utf-8 -*-
"""诊断: work左边缘串格 + left peek收回帧白色遮挡"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

GIFDIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"

def frame_bbox(im, i):
    im.seek(i)
    a = im.convert("RGBA").getchannel("A")
    b = a.getbbox()
    return b, a

# ===== 诊断1: work 各帧左边缘 =====
print("="*60)
print("work.gif 各帧左边缘(最左8px列带)不透明像素")
im = Image.open(os.path.join(GIFDIR, "work.gif"))
for i in range(im.n_frames):
    im.seek(i)
    f = im.convert("RGBA")
    a = f.getchannel("A")
    w, h = f.size
    edge_l = sum(1 for y in range(h) for x in range(8) if a.getpixel((x, y)) > 100)
    edge_r = sum(1 for y in range(h) for x in range(w-8, w) if a.getpixel((x, y)) > 100)
    edge_t = sum(1 for x in range(w) for y in range(8) if a.getpixel((x, y)) > 100)
    edge_b = sum(1 for x in range(w) for y in range(h-8, h) if a.getpixel((x, y)) > 100)
    print(f"  帧{i+1}: 左{edge_l:4d} 右{edge_r:4d} 上{edge_t:4d} 下{edge_b:4d}  尺寸{w}x{h}")

# ===== 诊断2: work 源图左边缘(第1列格 x0-260) =====
print()
print("work 源图: 第1列格左边缘内容分布(找串格源)")
SRC = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\work 精灵图.png"
si = Image.open(SRC).convert("RGBA")
sw, sh = si.size
def close(c1, c2, t=45):
    return sum((a-b)**2 for a, b in zip(c1[:3], c2[:3]))**0.5 < t
# 列1格范围 x[0,252], 行1 y[0,617] / 行2 y[617,1254]
for ri, (ya, yb) in enumerate([(0, 617), (617, sh)]):
    # 该格右边界 x 245-252 是否有内容(可能属本格角色)
    n = sum(1 for y in range(ya+4, yb-4, 2) for x in range(245, 252) if not close(si.getpixel((x, y))[:3], (255,255,255)))
    n2 = sum(1 for y in range(ya+4, yb-4, 2) for x in range(252, 262) if not close(si.getpixel((x, y))[:3], (255,255,255)))
    print(f"  行{ri+1}: x245-252 内容像素 {n}, x252-262 内容像素 {n2}")

# ===== 诊断3: left peek 收回帧(帧7-8) 白色遮挡 =====
print()
print("left peek.gif 收回帧(帧7-8)白色块检查")
lim = Image.open(os.path.join(GIFDIR, "left peek.gif"))
for i in [6, 7]:
    lim.seek(i)
    f = lim.convert("RGBA")
    w, h = f.size
    a = f.getchannel("A")
    # 统计近白色不透明像素(白色遮挡 = 白色但alpha>0)
    white_opaque = 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if a.getpixel((x, y)) > 100:
                r, g, b, _ = f.getpixel((x, y))
                if r > 235 and g > 235 and b > 235:
                    white_opaque += 1
    print(f"  帧{i+1}: 尺寸{w}x{h}, 不透明白色像素约 {white_opaque*4} ({white_opaque*4*100.0/(w*h):.1f}%)")
