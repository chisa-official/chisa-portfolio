# -*- coding: utf-8 -*-
"""为爱弥斯成品gif目录下所有GIF生成预览拼图"""
import sys, glob, os, math
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

d = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"
for g in sorted(glob.glob(os.path.join(d, "*.gif"))):
    im = Image.open(g)
    n = im.n_frames
    dur = im.info.get("duration", 0)
    frames = []
    for i in range(n):
        im.seek(i)
        frames.append(im.convert("RGBA").copy())
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    w2, h2 = frames[0].size
    pad2 = 8
    canvas = Image.new("RGBA", (cols*(w2+pad2)+pad2, rows*(h2+pad2)+pad2), (255, 255, 255, 255))
    for i, f in enumerate(frames):
        r, c = divmod(i, cols)
        canvas.paste(f, (pad2 + c*(w2+pad2), pad2 + r*(h2+pad2)), f)
    pv = g.replace(".gif", "_preview.png")
    canvas.convert("RGB").save(pv)
    print(f"{os.path.basename(g)}: {n} frames {dur}ms -> preview OK")
