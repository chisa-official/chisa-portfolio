# -*- coding: utf-8 -*-
"""left peek: 移除全部封闭白色大块(异物), 保留小白色部件; 保存后自检"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

p = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif\left peek.gif"
THR = 1000

im = Image.open(p)
n = im.n_frames
frames = []
for i in range(n):
    im.seek(i)
    frames.append(im.convert("RGBA").copy())

total = 0
for fi, f in enumerate(frames):
    w, h = f.size
    a = f.getchannel("A")
    px = f.load()
    white_pts = set()
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if a.getpixel((x, y)) > 100:
                r, g, b, _ = px[x, y]
                if r > 235 and g > 235 and b > 235:
                    white_pts.add((x, y))
    seen = set()
    removed = 0
    for p0 in white_pts:
        if p0 in seen:
            continue
        stack = [p0]
        comp = []
        while stack:
            q = stack.pop()
            if q in seen:
                continue
            seen.add(q)
            comp.append(q)
            qx, qy = q
            for dx in (-2, 0, 2):
                for dy in (-2, 0, 2):
                    nq = (qx+dx, qy+dy)
                    if nq in white_pts and nq not in seen:
                        stack.append(nq)
        if len(comp) >= THR:
            xs = [c[0] for c in comp]
            ys = [c[1] for c in comp]
            touches = (min(xs) <= 4 or max(xs) >= w-5 or min(ys) <= 4 or max(ys) >= h-5)
            if not touches:
                for qx, qy in comp:
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            X, Y = qx*2+dx, qy*2+dy
                            if 0 <= X < w and 0 <= Y < h:
                                px[X, Y] = (255, 255, 255, 0)
                removed += 1
    if removed:
        print(f"帧{fi+1}: 移除 {removed} 个大块")
        total += removed
print("共移除:", total)

# 保存
ap = [S.to_gif_frame(f) for f in frames]
tr = ap[0].info["transparency"]
ap[0].save(p, save_all=True, append_images=ap[1:],
           duration=250, loop=0, disposal=2, transparency=tr, optimize=False)
print("已保存:", p)

# 自检: 读回, 检查每帧最大白色连通域
im2 = Image.open(p)
for i in range(im2.n_frames):
    im2.seek(i)
    f2 = im2.convert("RGBA")
    w2, h2 = f2.size
    a2 = f2.getchannel("A")
    px2 = f2.load()
    wp = set()
    for y in range(0, h2, 2):
        for x in range(0, w2, 2):
            if a2.getpixel((x, y)) > 100:
                r, g, b, _ = px2[x, y]
                if r > 235 and g > 235 and b > 235:
                    wp.add((x, y))
    seen = set()
    mx = 0
    for p0 in wp:
        if p0 in seen:
            continue
        stack = [p0]
        cnt = 0
        while stack:
            q = stack.pop()
            if q in seen:
                continue
            seen.add(q)
            cnt += 1
            qx, qy = q
            for dx in (-2, 0, 2):
                for dy in (-2, 0, 2):
                    nq = (qx+dx, qy+dy)
                    if nq in wp and nq not in seen:
                        stack.append(nq)
        mx = max(mx, cnt)
    print(f"  自检帧{i+1}: 最大白色连通域 {mx} 点")
