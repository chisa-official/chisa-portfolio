# -*- coding: utf-8 -*-
"""1px 级精确分隔线检测: 找全白行列(含1px细缝), 输出每张图的真实网格边界"""
import os, sys
from PIL import Image

DIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图"

def close(c1, c2, t=45):
    return sum((a-b)**2 for a, b in zip(c1[:3], c2[:3]))**0.5 < t

def full_white_runs(proj, min_w=1):
    """proj: 每像素内容量; 返回全白(内容=0)的连续区间"""
    runs = []
    i = 0
    while i < len(proj):
        if proj[i] == 0:
            j = i
            while j < len(proj) and proj[j] == 0:
                j += 1
            if j - i >= min_w:
                runs.append((i, j))
            i = j
        else:
            i += 1
    return runs

for name in sorted(os.listdir(DIR)):
    if not name.endswith(".png"):
        continue
    im = Image.open(os.path.join(DIR, name)).convert("RGB")
    w, h = im.size
    px = im.load()
    # 逐像素列投影(内容=非背景)
    colp = [0]*w
    step = max(1, h // 2000)  # 采样步长(大图加速)
    for y in range(0, h, step):
        for x in range(w):
            if not close(px[x, y], (255, 255, 255), 50):
                colp[x] += 1
    rowp = [0]*h
    step2 = max(1, w // 2000)
    for x in range(0, w, step2):
        for y in range(h):
            if not close(px[x, y], (255, 255, 255), 50):
                rowp[y] += 1
    cv = full_white_runs(colp, 1)
    rv = full_white_runs(rowp, 1)
    # 只保留内部(非边缘)缝隙
    cv_in = [r for r in cv if r[0] > 3 and r[1] < w-3]
    rv_in = [r for r in rv if r[0] > 3 and r[1] < h-3]
    print(f"=== {name}  {w}x{h}")
    print(f"  列全白缝隙(内部): {cv_in}")
    print(f"  行全白缝隙(内部): {rv_in}")
    print(f"  推断列数: {len(cv_in)+1}  推断行数: {len(rv_in)+1}")
