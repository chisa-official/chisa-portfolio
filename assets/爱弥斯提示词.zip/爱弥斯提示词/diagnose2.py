# -*- coding: utf-8 -*-
"""精细定位: work帧边缘内容结构 + left peek白色块位置"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

GIFDIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"

# ===== work: 帧1/帧2 左边缘内容的结构 =====
im = Image.open(os.path.join(GIFDIR, "work.gif"))
for fi in [0, 1]:
    im.seek(fi)
    f = im.convert("RGBA")
    w, h = f.size
    a = f.getchannel("A")
    print(f"--- work 帧{fi+1} ({w}x{h}) 左边缘带(x0-14) ASCII ---")
    # 左 15px 带, 按 y 每 8px 一行
    for y in range(0, h, 8):
        line = ""
        for x in range(15):
            if a.getpixel((x, y)) > 100:
                r, g, b, _ = f.getpixel((x, y))
                # 白色=桌/高光, 彩色=角色
                if r > 230 and g > 230 and b > 230: line += "w"
                else: line += "#"
            else:
                line += " "
        print(f"  y{y:3d}: |{line}|")
    print()

# ===== left peek 帧7: 白色块定位 =====
print("=== left peek 帧7 白色块定位 ===")
lim = Image.open(os.path.join(GIFDIR, "left peek.gif"))
lim.seek(6)
f = lim.convert("RGBA")
w, h = f.size
a = f.getchannel("A")
# 找白色不透明像素的连通域
white_pts = set()
for y in range(0, h, 2):
    for x in range(0, w, 2):
        if a.getpixel((x, y)) > 100:
            r, g, b, _ = f.getpixel((x, y))
            if r > 235 and g > 235 and b > 235:
                white_pts.add((x, y))
print(f"帧7: {w}x{h}, 白色不透明采样点 {len(white_pts)}")
# 连通域
seen = set()
comps = []
for p in white_pts:
    if p in seen: continue
    stack = [p]; comp = []
    while stack:
        q = stack.pop()
        if q in seen: continue
        seen.add(q); comp.append(q)
        qx, qy = q
        for dx in (-2, 0, 2):
            for dy in (-2, 0, 2):
                nq = (qx+dx, qy+dy)
                if nq in white_pts and nq not in seen:
                    stack.append(nq)
    comps.append(comp)
comps.sort(key=len, reverse=True)
print(f"白色连通域: {len(comps)} 个")
for i, c in enumerate(comps[:6]):
    xs = [p[0] for p in c]; ys = [p[1] for p in c]
    print(f"  域{i+1}: 采样点{len(c)} bbox x[{min(xs)}-{max(xs)}] y[{min(ys)}-{max(ys)}] 面积约{len(c)*4}px")
