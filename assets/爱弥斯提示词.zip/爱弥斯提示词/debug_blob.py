# -*- coding: utf-8 -*-
"""调试: blob去块后 保存->读取 是否保留透明"""
import sys, os, tempfile
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

p = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif\left peek.gif"
im = Image.open(p)
im.seek(1)
f = im.convert("RGBA").copy()
w, h = f.size
a = f.getchannel("A")
px = f.load()

# 找白色连通域(采样步2)
white_pts = set()
for y in range(0, h, 2):
    for x in range(0, w, 2):
        if a.getpixel((x, y)) > 100:
            r, g, b, _ = px[x, y]
            if r > 235 and g > 235 and b > 235:
                white_pts.add((x, y))
seen = set()
big_comp = None
for p0 in white_pts:
    if p0 in seen: continue
    stack = [p0]; comp = []
    while stack:
        q = stack.pop()
        if q in seen: continue
        seen.add(q); comp.append(q)
        qx, qy = q
        for dx in (-2, 0, 2):
            for dy in (-2, 0, 2):
                nq = (qx+dx, qy+dy)
                if nq in white_pts and nq not in seen:
                    stack.append(nq)
    if big_comp is None or len(comp) > len(big_comp):
        big_comp = comp
print("最大白色连通域采样点:", len(big_comp) if big_comp else 0)
if not big_comp:
    sys.exit(0)

# 记录要清除的实际像素坐标
target = set()
for qx, qy in big_comp:
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            X, Y = qx*2+dx, qy*2+dy
            if 0 <= X < w and 0 <= Y < h:
                target.add((X, Y))
print("目标像素数:", len(target))
# 内存中清除
for X, Y in target:
    px[X, Y] = (255, 255, 255, 0)
# 验证内存
cnt = sum(1 for X, Y in target if px[X, Y][3] > 100)
print("内存中清除后 alpha>100 的目标像素:", cnt, " (应为0)")

# 保存再读
tmp = os.path.join(tempfile.gettempdir(), "blobtest2.gif")
ap = [S.to_gif_frame(f)]
tr = ap[0].info["transparency"]
ap[0].save(tmp, save_all=True, append_images=[], duration=250, loop=0, disposal=2, transparency=tr, optimize=False)
back = Image.open(tmp)
b2 = back.convert("RGBA")
cnt2 = sum(1 for X, Y in target if b2.getpixel((X, Y))[3] > 100)
print("读取后目标像素 alpha>100:", cnt2, " (应接近0)")
# 调色板检查
pal = back.getpalette()
print("GIF调色板透明索引:", back.info.get("transparency"))
