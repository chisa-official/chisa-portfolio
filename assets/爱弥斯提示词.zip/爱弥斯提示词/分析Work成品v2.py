# -*- coding: utf-8 -*-
"""Work 成品精细分析 v2: 跨格找黄金瞳直径 + 角色服饰色系(排除桌/笔记本)"""
import os, sys
from PIL import Image
sys.path.insert(0, r"D:\trae work\绘制gif动图")
import sprite_to_gif as S

FOLDER = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图"
WORK = os.path.join(FOLDER, "work 精灵图.png")

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3], c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    step = max(8, min(w,h)//80)
    ring = []
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

im = Image.open(WORK).convert("RGBA")
w,h = im.size
cw, ch = w//5, h//2
bg = detect_bg(im)
px = im.convert("RGB")

# ===== 跨格扫描黄金瞳 =====
def is_gold(c):
    r,g,b = c
    return r > 190 and g > 130 and b < 130 and r > b + 60

best = None
for r_ in range(2):
    for c_ in range(5):
        box = (c_*cw+4, r_*ch+4, (c_+1)*cw-4, (r_+1)*ch-4)
        gold = []
        for y in range(box[1], box[3], 2):
            for x in range(box[0], box[2], 2):
                if is_gold(px.getpixel((x,y))):
                    gold.append((x,y))
        if len(gold) > 30:
            # 聚类两瞳
            groups = []
            for p in gold:
                placed = False
                for g2 in groups:
                    if abs(g2[0][0]-p[0]) < 50 and abs(g2[0][1]-p[1]) < 50:
                        g2.append(p); placed = True; break
                if not placed: groups.append([p])
            groups.sort(key=len, reverse=True)
            if groups:
                g2 = groups[0]
                xs=[p[0] for p in g2]; ys=[p[1] for p in g2]
                d = max(max(xs)-min(xs), max(ys)-min(ys))
                print(f"格{r_+1},{c_+1}: 金像素{len(gold)} 最大瞳bbox {max(xs)-min(xs)}x{max(ys)-min(ys)} 直径≈{d}px")
                if best is None or len(gold) > best[0]:
                    best = (len(gold), d, r_, c_)
print("最佳黄金瞳格:", best)

# ===== 角色服饰色系(排除桌/笔记本的棕/灰色) =====
# 取中间格, 躯干/下装区, 按色系分类
box = (2*cw+4, 0*ch+4, 3*cw-4, 1*ch-4)
x0,y0 = box[0], box[1]
bw, bh = cw-8, ch-8
def classify(c):
    r,g,b = c
    if abs(r-255)<25 and abs(g-255)<25 and abs(b-255)<25: return "white"
    if r>180 and g>110 and b>140 and b > r-60: return "pink"       # 粉
    if r>150 and g>90 and b>110 and b > r-40: return "pink-dark"   # 深粉/玫红
    if r>110 and g<r and b<g-20 and r<200: return "brown"          # 棕(桌)
    if abs(r-g)<18 and abs(g-b)<18: return "gray"                  # 灰(笔记本/阴影)
    if b > r+15 and b > 130: return "blue-ish"                     # 蓝
    return "other"
from collections import Counter
for name, (ya, yb) in {"上装(40-65%)": (0.40,0.65), "下装(65-90%)": (0.65,0.90), "底部(90-100%)": (0.90,1.0)}.items():
    cnt = Counter()
    for y in range(y0+int(bh*ya), y0+int(bh*yb), 2):
        for x in range(x0, x0+bw, 2):
            c = px.getpixel((x,y))
            if not close(c, bg, 50):
                cnt[classify(c)] += 1
    tot = sum(cnt.values())
    print(f"{name}: " + ", ".join(f"{k} {v*100.0/max(1,tot):.0f}%" for k,v in cnt.most_common()))
