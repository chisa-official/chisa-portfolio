# -*- coding: utf-8 -*-
"""放大查看 left peek 源图帧6 脸部区域(原去块位置 x1099-1441 y2636-2834 附近)"""
import sys
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

im = Image.open(r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png").convert("RGBA")
# 帧6 = 行2列2: 内容 x[939,1752] y[2177,4058]
# 原blob位于 帧坐标 x196-538 y456-654 -> 源坐标 x1139-1481 y2633-2831
x0, x1, y0, y1 = 1050, 1550, 2500, 3000
crop = im.crop((x0, y0, x1, y1))
W, H = 60, 44
crop = crop.resize((W, H))
px = crop.load()
for y in range(H):
    line = ""
    for x in range(W):
        r, g, b = px[x, y][:3]
        if abs(r-255) < 30 and abs(g-255) < 30 and abs(b-255) < 30:
            line += " "
        elif r > 235 and g > 235 and b > 235:
            line += "W"
        elif r > 210 and g > 160 and b > 150:
            line += "p"
        elif r > 220 and g > 175 and b > 135 and b < 200:
            line += "s"
        elif r > 150 and g > 90 and b > 90 and b > r-40:
            line += "m"
        elif r > 200 and g > 190 and b < 160:
            line += "g"
        else:
            line += "#"
    print(line)
