# -*- coding: utf-8 -*-
"""左探头精灵图 -> 右探头: 稳健拆格(内容簇聚类) + 镜像"""
import os, sys
from PIL import Image
sys.path.insert(0, r"D:\trae work\绘制gif动图")
import sprite_to_gif as S

SRC = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png"
OUT_R = r"D:\trae work\绘制gif动图\成品图\peek_right.gif"
OUT_L = r"D:\trae work\绘制gif动图\成品图\peek_left.gif"
DURATION = 250

im = Image.open(SRC).convert("RGBA")
w, h = im.size
BG = (250, 250, 250)

def close(c1, c2, t=45):
    return sum((a-b)**2 for a, b in zip(c1[:3], c2[:3]))**0.5 < t

def proj(axis, y0=0, y1=None, x0=0, x1=None):
    y1 = y1 or h; x1 = x1 or w
    out = []
    if axis == 0:  # 列
        for x in range(x0, x1, 2):
            n = sum(1 for y in range(y0, y1, 4) if not close(im.getpixel((x, y))[:3], BG))
            out.append(n)
    else:
        for y in range(y0, y1, 2):
            n = sum(1 for x in range(x0, x1, 4) if not close(im.getpixel((x, y))[:3], BG))
            out.append(n)
    return out

def smooth(p, win=25):
    out = []
    for i in range(len(p)):
        a = max(0, i-win); b = min(len(p), i+win+1)
        out.append(sum(p[a:b])/(b-a))
    return out

def find_gaps(proj, min_gap_px, max_content):
    """找近空白带(宽>=min_gap_px 且内容<=max_content)"""
    gaps = []
    i = 0
    while i < len(proj):
        if proj[i] <= max_content:
            j = i
            while j < len(proj) and proj[j] <= max_content:
                j += 1
            wpx = (j - i) * 2
            if wpx >= min_gap_px:
                gaps.append((i*2, j*2, (i+j)))  # (start,end,center*2)
            i = j
        else:
            i += 1
    return gaps

# 1. 行分割: 中部最宽空白带
rp = smooth(proj(1), 20)
row_gaps = find_gaps(rp, 80, int(w*0.005/4))
mid = [g for g in row_gaps if h*0.25 < g[0] < h*0.75]
print("中部行空白带:", mid)
row_split = max(mid, key=lambda g: g[1]-g[0])[2]//1 if mid else h//2
print("行分割 y =", int(row_split))

# 2. 列边界: 用顶部行(内容最干净)聚类出 4 列, 作为两行共用模板
def col_clusters(ya, yb, merge_gap=60):
    cp = smooth(proj(0, ya, yb), 15)
    runs = []
    i = 0
    thr = int((yb-ya)*0.004/4)
    while i < len(cp):
        if cp[i] > thr:
            j = i
            while j < len(cp) and cp[j] > thr:
                j += 1
            runs.append([i*2, j*2])
            i = j
        else:
            i += 1
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] < merge_gap:
            merged[-1][1] = r[1]
        else:
            merged.append(list(r))
    merged.sort(key=lambda r: r[1]-r[0], reverse=True)
    top4 = sorted(merged[:4], key=lambda r: r[0])
    return top4

top_band = (0, int(row_split))
clusters = col_clusters(*top_band)
print("顶部行4簇(列边界):", clusters)
if len(clusters) != 4:
    print("!! 顶部行未得4簇, 中止")
    sys.exit(1)

# 用列边界生成 2 行 x 4 列格子
col_bounds = []
prev = 0
for x0, x1 in clusters:
    col_bounds.append((prev, x1))
    prev = x0
# 更简单: 每簇取 [x0-8, x1+8] 为格
cells = []
rows = [(0, int(row_split)), (int(row_split), h)]
for ri, (ya, yb) in enumerate(rows):
    for c_i, (x0, x1) in enumerate(clusters):
        cells.append((ri, c_i, max(0, x0-10), min(w, x1+10), ya, yb))

print("最终拆格:", [(r, c, x0, x1) for r, c, x0, x1, _, _ in cells])
if len(cells) != 8:
    print("!! 格数 != 8, 中止")
    sys.exit(1)

frames_r, frames_l = [], []
inset = 8
for r, c, x0, x1, ya, yb in cells:
    box = (x0+inset, ya+inset, x1-inset, yb-inset)
    cell = im.crop(box).copy()
    cell = S.flood_fill_bg(cell, 30)
    frames_l.append(cell)
    frames_r.append(cell.transpose(Image.FLIP_LEFT_RIGHT))
print("帧数:", len(frames_l))

def save_gif(frames, path):
    ap = [S.to_gif_frame(f) for f in frames]
    tr = ap[0].info["transparency"]
    ap[0].save(path, save_all=True, append_images=ap[1:],
               duration=DURATION, loop=0, disposal=2, transparency=tr, optimize=False)
    print("已保存:", path, len(ap), "帧")

save_gif(frames_r, OUT_R)
save_gif(frames_l, OUT_L)
