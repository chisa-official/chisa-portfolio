# -*- coding: utf-8 -*-
"""最终验收: 基线稳定性 + work边缘 + 预览重新生成"""
import sys, os, glob, math
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

D = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"

for g in sorted(glob.glob(os.path.join(D, "*.gif"))):
    name = os.path.basename(g)
    im = Image.open(g)
    n = im.n_frames
    frames = []
    for i in range(n):
        im.seek(i)
        frames.append(im.convert("RGBA").copy())
    # 内容底部(基线)
    bottoms = []
    for f in frames:
        b = f.getchannel("A").getbbox()
        bottoms.append(b[3] if b else None)
    bs = [b for b in bottoms if b is not None]
    span = max(bs) - min(bs) if bs else 0
    # 边缘检查(最外4px)
    edge = 0
    for f in frames:
        a = f.getchannel("A")
        w2, h2 = f.size
        for x in range(w2):
            for y in range(4):
                if a.getpixel((x, y)) > 100: edge += 1
                if a.getpixel((x, h2-1-y)) > 100: edge += 1
        for y in range(h2):
            for x in range(4):
                if a.getpixel((x, y)) > 100: edge += 1
                if a.getpixel((w2-1-x, y)) > 100: edge += 1
    print(f"{name:16s} 帧数{n} 基线跨度{span:4d}px 边缘不透明像素{edge:5d} 尺寸{frames[0].size}")
    # 预览
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    w2, h2 = frames[0].size
    pad2 = 8
    canvas = Image.new("RGBA", (cols*(w2+pad2)+pad2, rows*(h2+pad2)+pad2), (255, 255, 255, 255))
    for i, f in enumerate(frames):
        r, c = divmod(i, cols)
        canvas.paste(f, (pad2 + c*(w2+pad2), pad2 + r*(h2+pad2)), f)
    canvas.convert("RGB").save(g.replace(".gif", "_preview.png"))
print("预览已全部重新生成")
