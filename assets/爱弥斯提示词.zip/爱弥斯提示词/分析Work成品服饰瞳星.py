# -*- coding: utf-8 -*-
"""分析 Work 成品精灵图: 服饰配色 / 黄金瞳直径 / 四芒星芒尖距 / 胸口爱心"""
import os, sys
from PIL import Image

sys.path.insert(0, r"D:\trae work\绘制gif动图")
import sprite_to_gif as S

FOLDER = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图"
WORK = os.path.join(FOLDER, "work 精灵图.png")

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3], c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    step = max(8, min(w,h)//80)
    ring = []
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

def cell_bbox(im, bg, box):
    x0,y0,x1,y1 = box
    px = im.convert("RGB")
    minx,miny,maxx,maxy = x1,y1,-1,-1
    for y in range(y0,y1,2):
        for x in range(x0,x1,2):
            if not close(px.getpixel((x,y)), bg, 50):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx<0: return None
    return (minx,miny,maxx,maxy)

def clusters(im, box, n=6):
    crop = im.crop(box).convert("RGB")
    if crop.size[0]<4 or crop.size[1]<4: return []
    q = crop.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(c for c,_ in cnt))
    return [("#%02X%02X%02X" % tuple(pal[i*3:i*3+3]), round(c*100.0/tot,1)) for c,i in cnt]

im = Image.open(WORK).convert("RGBA")
w,h = im.size
print("Work 成品尺寸:", im.size)
cols, rows, vg, hg = S.detect_grid(im)
print("自动网格:", cols, "x", rows)
cw, ch = w//5, h//2
bg = detect_bg(im)

# 取中间格(第3格)全面测量
box = (2*cw+4, 0*ch+4, 3*cw-4, 1*ch-4)
bb = cell_bbox(im, bg, box)
print("第3格内容bbox:", bb)
x0,y0,x1,y1 = bb
bh = y1-y0; bw = x1-x0
px = im.convert("RGB")

# ===== 1. 服饰分区主色 =====
torso = (x0, y0+int(bh*0.42), x1, y0+int(bh*0.72))     # 上装(胸部以下避开脸)
skirt = (x0, y0+int(bh*0.68), x1, y0+int(bh*0.88))     # 裙/下装
legs  = (x0, y0+int(bh*0.80), x1, y0+int(bh*0.96))     # 腿袜
shoes = (x0, y1-int(bh*0.08), x1, y1)                   # 鞋
print("上装区主色:", clusters(im, torso))
print("裙/下装区主色:", clusters(im, skirt))
print("腿/袜区主色:", clusters(im, legs))
print("鞋区主色:", clusters(im, shoes))

# ===== 2. 胸口爱心痕迹(颈部下方 ~38%-50% 高度, 中央区域) =====
chest = (x0+int(bw*0.3), y0+int(bh*0.36), x0+int(bw*0.7), y0+int(bh*0.50))
print("胸口区主色:", clusters(im, chest, 8))
# 蓝粉色像素统计(胸口区)
bluepink = 0; totc = 0
for y in range(chest[1], chest[3], 1):
    for x in range(chest[0], chest[2], 1):
        r,g,b = px.getpixel((x,y))
        totc += 1
        if (b > r-30 and b > 140 and r > 120) or (r > 180 and b > 150 and g > 100 and abs(r-b) < 80):
            bluepink += 1
print(f"胸口区蓝粉像素占比: {bluepink*100.0/max(1,totc):.1f}%")

# ===== 3. 黄金瞳直径 =====
# 面部区: 头部区下部(眼睛位置)
face = (x0, y0+int(bh*0.20), x1, y0+int(bh*0.42))
gold_pts = []
for y in range(face[1], face[3], 1):
    for x in range(face[0], face[2], 1):
        r,g,b = px.getpixel((x,y))
        if r > 190 and g > 130 and b < 150 and r > b + 60:  # 金黄琥珀
            gold_pts.append((x,y))
if gold_pts:
    gx = [p[0] for p in gold_pts]; gy = [p[1] for p in gold_pts]
    # 按 x 聚类成两只眼
    from collections import defaultdict
    groups = []
    for p in gold_pts:
        placed = False
        for g2 in groups:
            if abs(g2[0][0]-p[0]) < 40 and abs(g2[0][1]-p[1]) < 40:
                g2.append(p); placed = True; break
        if not placed: groups.append([p])
    groups.sort(key=len, reverse=True)
    print("黄金瞳聚类数:", len(groups))
    for i, g2 in enumerate(groups[:3]):
        xs=[p[0] for p in g2]; ys=[p[1] for p in g2]
        print(f"  瞳{i+1}: 像素{len(g2)} bbox 宽{max(xs)-min(xs)}px 高{max(ys)-min(ys)}px 中心({(min(xs)+max(xs))//2},{(min(ys)+max(ys))//2})")
    # 最大瞳直径
    g2 = groups[0]
    xs=[p[0] for p in g2]; ys=[p[1] for p in g2]
    eye_d = max(max(xs)-min(xs), max(ys)-min(ys))
    print(f"最大黄金瞳直径 ≈ {eye_d}px")
else:
    print("未检出黄金瞳像素(可能闭眼/角度)")
    eye_d = None

# ===== 4. 四芒星芒尖距 =====
# 头部区找淡蓝边缘像素, 聚成连通域, 取最上方一簇(星)
head = (x0, y0, x1, y0+int(bh*0.45))
blue_pts = []
for y in range(head[1], head[3], 1):
    for x in range(head[0], head[2], 1):
        r,g,b = px.getpixel((x,y))
        if b > r + 25 and b > 150 and g > 120 and abs(g-b) < 90:
            blue_pts.append((x,y))
print("头部区淡蓝像素:", len(blue_pts))
if blue_pts:
    # 连通域(粗聚类)
    groups = []
    for p in blue_pts:
        placed = False
        for g2 in groups:
            if abs(g2[0][0]-p[0]) < 15 and abs(g2[0][1]-p[1]) < 15:
                g2.append(p); placed = True; break
        if not placed: groups.append([p])
    groups.sort(key=len, reverse=True)
    print("淡蓝连通域数:", len(groups), " 最大簇像素:", len(groups[0]) if groups else 0)
    # 星 = 最靠上的大簇
    for i, g2 in enumerate(groups[:4]):
        xs=[p[0] for p in g2]; ys=[p[1] for p in g2]
        # 芒尖距 = 簇内任意两像素最大距离(近似的对尖距)
        maxd = 0
        # 粗略: 四个极端点(左上右上左下右下)中取最远
        pts4 = [(min(xs),min(ys)),(max(xs),min(ys)),(min(xs),max(ys)),(max(xs),max(ys))]
        for a in pts4:
            for b_ in pts4:
                d = ((a[0]-b_[0])**2+(a[1]-b_[1])**2)**0.5
                if d>maxd: maxd=d
        print(f"  簇{i+1}: 像素{len(g2)} bbox 宽{max(xs)-min(xs)} 高{max(ys)-min(ys)} 四角最大距≈{maxd:.0f}px y范围{min(ys)}-{max(ys)}")
    # 星尺寸 vs 瞳直径
    if eye_d:
        print(f"\n>> 星bbox宽/瞳直径 = {89.0/eye_d:.2f}  (当前约40%头宽方案实测星宽{89}px)")
