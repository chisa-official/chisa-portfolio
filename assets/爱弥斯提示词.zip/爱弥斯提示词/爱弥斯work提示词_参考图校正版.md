# 爱弥斯 Work 精灵图提示词 · 参考图校正版（个人实验用）

> **用途**：在**支持上传参考图**的外部 GPT 渠道使用（用户个人尝试，不用于本项目 API 流水线）。
> **流程**：模型先分析上传的参考图 → 提取角色基本特征（发色/发型/脸型/瞳色等）→ 修正下方角色描述 → 用修正后的描述生成 Work 精灵图。
> **使用方式**：上传一张爱弥斯参考图（立绘/表情包皆可）+ 粘贴下方完整提示词。

---

## 完整提示词（可直接复制）

```
You will receive a reference image of an anime character together with this prompt. Follow
these steps in order.

STEP 1 — ANALYZE THE REFERENCE IMAGE
Carefully examine the uploaded reference image and extract the character's basic features:
- Hair color (exact shade, e.g. soft baby pink)
- Hairstyle (length, high ponytail, bangs, stray strands)
- Face shape (round / oval / pointed chin, etc.)
- Eye color and pupil shape (e.g. golden amber iris, star-shaped pupil)
- Skin tone
- Outfit (garment types, main colors, trims, details)
- Headwear and accessories (hair ornament, star shape, bird wings, hair clip, their size and position)
- Signature effects (mosaic glitch patterns on hair edges and skin, glitch particles)

STEP 2 — CORRECT THE CHARACTER DESCRIPTION
Compare your analysis with the "CHARACTER DESCRIPTION" below (this description has already
been validated against the reference image). If it already matches, reply exactly
"DESCRIPTION ACCEPTED — no changes needed" and keep it verbatim. If you find a clear
discrepancy, output ONLY the CORRECTED full character description in English, fixing just the
mismatching details (wrong colors, hairstyle / face shape / eye and pupil details, outfit and
accessories) and keep every correct detail unchanged — do not rewrite correct parts, do not
add unsupported details.

STEP 3 — GENERATE THE SPRITE SHEET
Using the CORRECTED description from Step 2 (not the original), draw the sprite sheet exactly
as specified below.

════════════ CHARACTER DESCRIPTION (reference — correct if needed) ════════════
A cute chibi anime girl character, about 2.5-head chibi proportion, full body. She is an
electronic-ghost girl with soft baby-pink hair (light rose-pink) tied into a high ponytail,
with lighter near-white pink highlights at the crown and a few stray strands framing her round
face. Her hair edges and skin surface are decorated with faint SQUARE mosaic glitch effects:
small blocky blue-white pixel tiles with high transparency, without hiding her features.
Around her high ponytail she wears a large white hair ornament with BOLD light-blue edges, the
ring roughly the size of her head: a large FOUR-POINTED star on top, sized so the straight-line
distance between two opposite star tips is about 1.8 to 2.0 times the diameter of her large
golden eye (four equal points, definitely not a five-pointed star; clearly prominent, not too
small), and simplified bird wings on both sides positioned slightly behind her ears (the two
wings mirrored), wing roots pointing diagonally downward and wing tips pointing diagonally
forward. On the right side of her hair she wears a small simplified-bird-wing hair clip, white
with bold light-blue edges, wing root pointing diagonally downward and wing tip pointing
diagonally backward. Her face is round with fair peach skin and large golden amber eyes whose
pupils are small four-pointed stars like the NATO emblem compass star, white with red edges.
She wears a light-pink and white outfit: a short light-pink jacket top with white trim over a
matching pink skirt with a white hem, thin blue electronic-glitch line accents, and a small
blue-pink heart mark on her chest. White legwear and pink shoes. Tiny blue holographic glitch
particles drift around her. The character always wears the same light-pink and white outfit
and is always drawn in the same flat-cel anime style with clean thick outlines; only the camera
angle and the action change.

════════════ SPRITE SHEET REQUEST ════════════
Draw this character as a sprite sheet: a 2 rows x 5 columns grid of 10 frames, read left to right, top to bottom.
She is sitting behind a small light-brown wooden desk with a gray laptop on it, working seriously as an electronic ghost.
Every cell shows the exact same character with identical design, scale and position, fully inside its cell with a small margin, cells separated by thin white gaps. Plain pure white background in every cell, no ground shadow, no text, no numbers, no labels, no watermark.

Frame 1: sitting behind the desk, hands on the keyboard, head slightly down, focused expression.
Frame 2: typing, hands lifted above the keyboard.
Frame 3: typing, hands down, fingers pressing the keys.
Frame 4: head tilting down toward the screen, hands resting on the keyboard.
Frame 5: head tilting to the right side, thoughtful expression, one hand near her chin.
Frame 6: head back up, hands lifting to type again.
Frame 7: typing, hands down on the keys.
Frame 8: head tilting slightly to the left, golden eyes fixed on the screen.
Frame 9: head up with a small satisfied smile.
Frame 10: back to the frame 1 pose, hands on keyboard, head slightly down, focused.

Keep her hair color, hairstyle, face shape, eye color, outfit and accessories exactly identical; only the camera angle and the action change.
```

---

## 说明

| 部分 | 作用 |
|---|---|
| STEP 1 | 让模型先"看图"，提取发色/发型/脸型/瞳色/服装/头饰/特效等基本特征 |
| STEP 2 | 与现有描述比对，**输出修正后的完整角色描述**（可看到它改了哪里），保留正确细节 |
| STEP 3 | 用修正后的描述生成 Work 精灵图（网格+逐帧动作不变） |
| 角色描述块 | 我们现有的 [A] 基底（细化版），作为"待校正底稿" |
| 精灵图请求块 | 与原 Work 提示词完全一致的网格/帧/锚点句 |

> 若外部渠道无法接受长提示词，可只发 STEP 1-2 让它先输出修正描述，确认后再发 STEP 3 部分。
