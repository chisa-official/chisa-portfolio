# -*- coding: utf-8 -*-
"""忠实重建: 用精确分隔线拆格, 帧保持原格位置(不居中不移位), 输出到爱弥斯成品gif"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

SRC_DIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图"
OUT_DIR = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif"

# (文件名, 输出名, 列缝, 行缝, 帧速)
JOBS = [
    ("boot 精灵图.png",     "boot.gif",       [855, 1644, 2448, 3254], [2073], 200),
    ("Idle 精灵图.png",     "Idle.gif",       [1052, 2052, 3048],      [],     300),
    ("walk 精灵图.png",     "walk.gif",       [1088, 2094, 3116],      [2094], 200),
    ("right peek 精灵图.png", "right peek.gif", [323, 670, 945],       [670],  250),
    ("Shutdown 精灵图.png", "Shutdown.gif",   [255, 505, 750, 997],    [700],  300),
    ("work 精灵图.png",     "work.gif",       [252, 503, 753, 1004],   [617],  200),
    ("left peek 精灵图.png", "left peek.gif", [68, 900, 2038, 3074],   [2177], 250),  # 无白缝, 用内容簇边界
]

INSET = 3  # 边界内缩, 防止串格(宁缺勿串)

for fname, oname, cols_seps, row_seps, dur in JOBS:
    im = Image.open(os.path.join(SRC_DIR, fname)).convert("RGBA")
    w, h = im.size

    # left peek 无白缝: 用显式格框(内容簇边界), 其余用分隔线
    if fname == "left peek 精灵图.png":
        cell_boxes = []
        for ri in range(2):
            ya, yb = (0, 2177) if ri == 0 else (2177, h)
            for (xa, xb) in [(68, 368), (900, 1754), (2038, 2952), (3074, 4016)]:
                cell_boxes.append((xa, ya, xb, yb))
        print(f"===== {fname} -> {oname}  网格 4x2 (显式格框)")
    else:
        col_bounds = [0] + cols_seps + [w]
        row_bounds = [0] + row_seps + [h]
        print(f"===== {fname} -> {oname}  网格 {len(col_bounds)-1}x{len(row_bounds)-1}")
        print(f"  列边界: {col_bounds}  行边界: {row_bounds}")
        cell_boxes = []
        for ri in range(len(row_bounds)-1):
            for ci in range(len(col_bounds)-1):
                cell_boxes.append((col_bounds[ci], row_bounds[ri],
                                   col_bounds[ci+1], row_bounds[ri+1]))

    frames = []
    for (xa, ya, xb, yb) in cell_boxes:
        box = (xa+INSET, ya+INSET, xb-INSET, yb-INSET)
        cell = im.crop(box).copy()
        cell = S.flood_fill_bg(cell, 30)
        frames.append(cell)

    # 统一画布: 所有帧粘贴到 (maxw, maxh), 保持各自原位置(左上对齐)
    maxw = max(f.width for f in frames)
    maxh = max(f.height for f in frames)
    padded = []
    for f in frames:
        c = Image.new("RGBA", (maxw, maxh), (255, 255, 255, 0))
        c.paste(f, (0, 0), f)
        padded.append(c)

    # 裁公共空白(仅统一裁剪, 不移位)
    minx = miny = 10**9
    maxx = maxy = 0
    for f in padded:
        b = f.getbbox()
        if b:
            minx = min(minx, b[0]); miny = min(miny, b[1])
            maxx = max(maxx, b[2]); maxy = max(maxy, b[3])
    if maxx > minx:
        pad = 4
        box2 = (max(0,minx-pad), max(0,miny-pad), min(maxw,maxx+pad), min(maxh,maxy+pad))
        padded = [f.crop(box2) for f in padded]
        print(f"  裁公共空白 -> {padded[0].size}")

    ap = [S.to_gif_frame(f) for f in padded]
    tr = ap[0].info["transparency"]
    out = os.path.join(OUT_DIR, oname)
    ap[0].save(out, save_all=True, append_images=ap[1:],
               duration=dur, loop=0, disposal=2, transparency=tr, optimize=False)
    print(f"  已保存 {oname}: {len(ap)} 帧, {dur}ms")

    # 串格检测: 每帧边缘 3px 内是否有不透明内容
    leak = 0
    for i, f in enumerate(padded):
        a = f.getchannel("A")
        w2, h2 = f.size
        edge = 0
        for x in range(w2):
            for y in range(3):
                if a.getpixel((x, y)) > 100: edge += 1
                if a.getpixel((x, h2-1-y)) > 100: edge += 1
        for y in range(h2):
            for x in range(3):
                if a.getpixel((x, y)) > 100: edge += 1
                if a.getpixel((w2-1-x, y)) > 100: edge += 1
        if edge > 0:
            leak += 1
            print(f"    WARN 帧{i+1}: 边缘有 {edge} 个不透明像素 (可能是角色自身贴近边缘, 也可能是串格)")
    if leak == 0:
        print("    OK 所有帧边缘无内容")
