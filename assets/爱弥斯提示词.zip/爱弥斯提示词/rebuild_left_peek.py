# -*- coding: utf-8 -*-
"""left peek 干净重建: 源图 -> 拆格 -> 去底 -> 移除封闭实心白块(正确坐标) -> 基线对齐 -> 自检"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

SRC = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png"
OUT = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif\left peek.gif"
ROW_SPLIT = 2177
COLS = [(68, 368), (900, 1754), (2038, 2952), (3074, 4016)]  # 4 列(内容簇边界)
INSET = 3
BLOB_THR = 2000   # 封闭白色连通域采样点阈值(>此值=异物实心块)
DURATION = 250

im = Image.open(SRC).convert("RGBA")
h = im.size[1]
frames = []
for ri, (ya, yb) in enumerate([(0, ROW_SPLIT), (ROW_SPLIT, h)]):
    for xa, xb in COLS:
        box = (xa+INSET, ya+INSET, xb-INSET, yb-INSET)
        cell = im.crop(box).copy()
        cell = S.flood_fill_bg(cell, 30)
        frames.append(cell)
print("拆帧:", len(frames))

# 移除封闭实心白块(正确坐标: 采样坐标即像素坐标, 不再x2)
total = 0
for fi, f in enumerate(frames):
    w, hh = f.size
    a = f.getchannel("A")
    px = f.load()
    wp = set()
    for y in range(0, hh, 2):
        for x in range(0, w, 2):
            if a.getpixel((x, y)) > 100:
                r, g, b, _ = px[x, y]
                if r > 230 and g > 230 and b > 230:
                    wp.add((x, y))
    seen = set()
    for p0 in wp:
        if p0 in seen:
            continue
        stack = [p0]; comp = []
        while stack:
            q = stack.pop()
            if q in seen: continue
            seen.add(q); comp.append(q)
            qx, qy = q
            for dx in (-2, 0, 2):
                for dy in (-2, 0, 2):
                    nq = (qx+dx, qy+dy)
                    if nq in wp and nq not in seen:
                        stack.append(nq)
        if len(comp) >= BLOB_THR:
            xs = [c[0] for c in comp]; ys = [c[1] for c in comp]
            touches = (min(xs) <= 4 or max(xs) >= w-5 or min(ys) <= 4 or max(ys) >= hh-5)
            if not touches:
                for qx, qy in comp:
                    px[qx, qy] = (255, 255, 255, 0)   # 采样坐标即像素坐标(步2), 直接置透明
                total += 1
    if total:
        pass
print("共移除封闭白块:", total)

# 基线对齐(底部)
bboxes = [f.getchannel("A").getbbox() for f in frames]
bottoms = [b[3] for b in bboxes if b]
baseline = max(bottoms)
shifts = [(baseline - b[3]) if b else 0 for b in bboxes]
W = max(f.width for f in frames)
H = max(f.height + s for f, s in zip(frames, shifts))
aligned = []
for f, s in zip(frames, shifts):
    c = Image.new("RGBA", (W, H), (255, 255, 255, 0))
    c.paste(f, (0, s), f)
    aligned.append(c)
print(f"基线: {baseline}, 画布 {W}x{H}, 最大下移 {max(shifts)}")

# 保存
ap = [S.to_gif_frame(f) for f in aligned]
tr = ap[0].info["transparency"]
ap[0].save(OUT, save_all=True, append_images=ap[1:],
           duration=DURATION, loop=0, disposal=2, transparency=tr, optimize=False)
print("已保存:", OUT)

# 自检
im2 = Image.open(OUT)
print("--- 自检 ---")
for i in range(im2.n_frames):
    im2.seek(i)
    f2 = im2.convert("RGBA")
    a2 = f2.getchannel("A")
    b = a2.getbbox()
    pct = sum(a2.histogram()[128:]) * 100.0 / (a2.size[0]*a2.size[1])
    # 最大白色连通域
    w2, h2 = f2.size
    px2 = f2.load()
    wp = set()
    for y in range(0, h2, 2):
        for x in range(0, w2, 2):
            if a2.getpixel((x, y)) > 100:
                r, g, b_, _ = px2[x, y]
                if r > 230 and g > 230 and b_ > 230:
                    wp.add((x, y))
    seen = set(); mx = 0
    for p0 in wp:
        if p0 in seen: continue
        stack = [p0]; cnt = 0
        while stack:
            q = stack.pop()
            if q in seen: continue
            seen.add(q); cnt += 1
            qx, qy = q
            for dx in (-2, 0, 2):
                for dy in (-2, 0, 2):
                    nq = (qx+dx, qy+dy)
                    if nq in wp and nq not in seen:
                        stack.append(nq)
        mx = max(mx, cnt)
    print(f"  帧{i+1}: 内容占比{pct:.1f}% 最大白色连通域{mx} (阈值2000)")
