# -*- coding: utf-8 -*-
"""检查当前 left peek 源图 帧6(行2列2) 脸部是否被遮挡"""
import sys
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image

im = Image.open(r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png").convert("RGBA")
x0, x1, y0, y1 = 900, 1754, 2177, 4096

def close(c1, c2, t=45):
    return sum((a-b)**2 for a, b in zip(c1[:3], c2[:3]))**0.5 < t

# 内容bbox
minx, miny, maxx, maxy = x1, y1, -1, -1
for y in range(y0, y1, 3):
    for x in range(x0, x1, 3):
        if not close(im.getpixel((x, y))[:3], (255, 255, 255)):
            minx = min(minx, x); maxx = max(maxx, x)
            miny = min(miny, y); maxy = max(maxy, y)
print("帧6内容bbox:", (minx, miny, maxx, maxy))
cw, ch = maxx-minx, maxy-miny
crop = im.crop((minx, miny, maxx, maxy))
W, H = 56, 48
crop = crop.resize((W, H))
px = crop.load()
for y in range(H):
    line = ""
    for x in range(W):
        r, g, b = px[x, y][:3]
        if abs(r-255) < 30 and abs(g-255) < 30 and abs(b-255) < 30:
            line += " "
        elif r > 230 and g > 228 and b > 228:
            line += "W"
        elif r > 210 and g > 160 and b > 150:
            line += "p"
        elif r > 220 and g > 170 and b > 130 and b < 200:
            line += "s"
        elif r > 150 and g > 100 and b > 100 and b > r-40:
            line += "m"
        elif r > 200 and g > 190 and b < 160:
            line += "g"
        else:
            line += "#"
    print(line)
