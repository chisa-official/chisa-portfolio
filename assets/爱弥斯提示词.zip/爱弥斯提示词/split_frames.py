# -*- coding: utf-8 -*-
"""通用稳健拆格: 对格间缝隙不规则/紧贴的精灵图, 按指定行列参数拆帧转GIF
用法: python split_frames.py <精灵图> <输出gif> <列缝列表(逗号)> <行缝y> <列数> <行数> <帧速ms>
例:  work:      python split_frames.py "work 精灵图.png" work.gif 254,510,762,1008 620 5 2 200
    left peek: python split_frames.py "left peek 精灵图.png" "left peek.gif" 68,900,2038,3074 2177 4 2 250
"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

SRC = sys.argv[1]
OUT = sys.argv[2]
seps = [int(x) for x in sys.argv[3].split(",")]
row_split = int(sys.argv[4])
COLS = int(sys.argv[5])
ROWS = int(sys.argv[6])
DURATION = int(sys.argv[7])

im = Image.open(SRC).convert("RGBA")
w, h = im.size
print("尺寸:", im.size, " 列缝:", seps, " 行缝:", row_split, f" 网格 {COLS}x{ROWS}")

# 列边界: 用列缝分隔
bounds = [0] + seps + [w]
if len(bounds) != COLS + 1:
    print(f"!! 列缝数({len(seps)})与列数({COLS})不匹配")
    sys.exit(1)

frames = []
inset = 4
for r in range(ROWS):
    ya = row_split if r == 1 else 0
    yb = row_split if r == 0 else h
    for c in range(COLS):
        box = (bounds[c] + inset, ya + inset, bounds[c+1] - inset, yb - inset)
        cell = im.crop(box).copy()
        cell = S.flood_fill_bg(cell, 30)
        frames.append(cell)
print("帧数:", len(frames))

ap = [S.to_gif_frame(f) for f in frames]
tr = ap[0].info["transparency"]
ap[0].save(OUT, save_all=True, append_images=ap[1:],
           duration=DURATION, loop=0, disposal=2, transparency=tr, optimize=False)
print("已保存:", OUT, len(ap), "帧,", DURATION, "ms")
