# -*- coding: utf-8 -*-
"""left peek 忠实重建: 源图原样 -> 拆格 -> 仅去白底 -> 基线对齐(不动其他像素)"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

SRC = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png"
OUT = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif\left peek.gif"
ROW_SPLIT = 2177
COLS = [(68, 368), (900, 1754), (2038, 2952), (3074, 4016)]
INSET = 3
DURATION = 250

im = Image.open(SRC).convert("RGBA")
h = im.size[1]
frames = []
for ri, (ya, yb) in enumerate([(0, ROW_SPLIT), (ROW_SPLIT, h)]):
    for xa, xb in COLS:
        box = (xa+INSET, ya+INSET, xb-INSET, yb-INSET)
        cell = im.crop(box).copy()
        cell = S.flood_fill_bg(cell, 30)   # 仅去白底, 不动其他像素
        frames.append(cell)
print("拆帧:", len(frames))

# 基线对齐(仅垂直移动, 不改变任何像素)
bboxes = [f.getchannel("A").getbbox() for f in frames]
bottoms = [b[3] for b in bboxes if b]
baseline = max(bottoms)
shifts = [(baseline - b[3]) if b else 0 for b in bboxes]
W = max(f.width for f in frames)
H = max(f.height + s for f, s in zip(frames, shifts))
aligned = []
for f, s in zip(frames, shifts):
    c = Image.new("RGBA", (W, H), (255, 255, 255, 0))
    c.paste(f, (0, s), f)
    aligned.append(c)
print(f"画布 {W}x{H}, 最大下移 {max(shifts)}px")

ap = [S.to_gif_frame(f) for f in aligned]
tr = ap[0].info["transparency"]
ap[0].save(OUT, save_all=True, append_images=ap[1:],
           duration=DURATION, loop=0, disposal=2, transparency=tr, optimize=False)
print("已保存:", OUT)

# 自检: 内容占比(与源图忠实度)
im2 = Image.open(OUT)
for i in range(im2.n_frames):
    im2.seek(i)
    f2 = im2.convert("RGBA")
    a2 = f2.getchannel("A")
    b = a2.getbbox()
    pct = sum(a2.histogram()[128:]) * 100.0 / (a2.size[0]*a2.size[1])
    print(f"  帧{i+1}: 内容占比{pct:.1f}%")
