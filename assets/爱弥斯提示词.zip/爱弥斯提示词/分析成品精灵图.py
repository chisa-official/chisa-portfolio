# -*- coding: utf-8 -*-
"""分析爱弥斯成品精灵图: Work 图四芒星尺寸 + Boot 图左下角分镜腿部比例"""
import os, sys
from PIL import Image

sys.path.insert(0, r"D:\trae work\绘制gif动图")
import sprite_to_gif as S

FOLDER = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图"
WORK = os.path.join(FOLDER, "work 精灵图.png")
BOOT = os.path.join(FOLDER, "boot 精灵图.png")

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3], c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    step = max(8, min(w,h)//80)
    ring = []
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

def cell_bbox(im, bg, box):
    x0,y0,x1,y1 = box
    px = im.convert("RGB")
    minx,miny,maxx,maxy = x1,y1,-1,-1
    for y in range(y0,y1,2):
        for x in range(x0,x1,2):
            if not close(px.getpixel((x,y)), bg, 50):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx<0: return None
    return (minx,miny,maxx,maxy)

# ============ WORK: 四芒星尺寸 ============
print("="*70)
print("WORK 精灵图分析")
imw = Image.open(WORK).convert("RGBA")
print("尺寸:", imw.size)
cols, rows, vg, hg = S.detect_grid(imw)
print("自动网格:", cols, "x", rows, " vg:", vg, " hg:", hg)
# 手动 5x2
cw, ch = imw.size[0]//5, imw.size[1]//2
bg = detect_bg(imw)
# 取一个中间格(第3格)测头饰
box3 = (2*cw+4, 0*ch+4, 3*cw-4, 1*ch-4)
bb = cell_bbox(imw, bg, box3)
print("第3格内容bbox:", bb)
if bb:
    x0,y0,x1,y1 = bb
    hh = y1-y0
    # 头部区 = 内容区顶部 45%
    head = (x0, y0, x1, y0+int(hh*0.45))
    # 天环头饰区: 头部区内找蓝色边缘像素
    px = imw.convert("RGB")
    blue_pts = []
    for y in range(head[1], head[3], 1):
        for x in range(head[0], head[2], 1):
            r,g,b = px.getpixel((x,y))
            # 淡蓝边缘: b 明显大于 r, 且偏亮 (BOLD light-blue ~ #9FD0F5)
            if b > r + 25 and b > 150 and g > 120 and abs(g-b) < 90:
                blue_pts.append((x,y))
    if blue_pts:
        xs = [p[0] for p in blue_pts]; ys = [p[1] for p in blue_pts]
        bw = max(xs)-min(xs); bh = max(ys)-min(ys)
        print(f"头部区淡蓝像素: {len(blue_pts)} 个, bbox 宽{bw}px 高{bh}px")
        print(f"  相对头部区宽度({head[2]-head[0]}px): 宽占比 {bw*100.0/(head[2]-head[0]):.1f}%, 高占比 {bh*100.0/hh:.1f}%")
        # 天环上方的星: 取淡蓝像素中 y 最小的 20% 部分(星的最上尖)
        ys_sorted = sorted(ys)
        top_y = ys_sorted[len(ys_sorted)//5]
        star_pts = [p for p in blue_pts if p[1] <= top_y]
        if star_pts:
            sxs = [p[0] for p in star_pts]; sys2 = [p[1] for p in star_pts]
            print(f"  星区(上方20%): 宽{max(sxs)-min(sxs)}px 高{max(sys2)-min(sys2)}px")
            print(f"  星相对头部宽度: {(max(sxs)-min(sxs))*100.0/(head[2]-head[0]):.1f}%  相对内容高度: {(max(sys2)-min(sys2))*100.0/hh:.1f}%")

# ============ BOOT: 左下角分镜腿部 ============
print()
print("="*70)
print("BOOT 精灵图分析")
imb = Image.open(BOOT).convert("RGBA")
print("尺寸:", imb.size)
cols2, rows2, vg2, hg2 = S.detect_grid(imb)
print("自动网格:", cols2, "x", rows2, " vg:", vg2, " hg:", hg2)
bg2 = detect_bg(imb)
# 左下角 = 第2行第1列 (2x5 网格 → Frame 6)
cw2, ch2 = imb.size[0]//5, imb.size[1]//2
cell6 = (0*cw2+4, 1*ch2+4, 1*cw2-4, 2*ch2-4)
bb6 = cell_bbox(imb, bg2, cell6)
print("左下角格内容bbox:", bb6)
if bb6:
    x0,y0,x1,y1 = bb6
    bw6, bh6 = x1-x0, y1-y0
    print(f"内容宽{bw6}px 高{bh6}px")
    # 下肢区 = 内容区底部 40%
    leg = (x0, y0+int(bh6*0.60), x1, y1)
    # 左右腿: 按 x 中位分左右, 测各腿最低点与最高点(脚/膝)
    pxb = imb.convert("RGB")
    left_pts, right_pts = [], []
    midx = (leg[0]+leg[2])//2
    for y in range(leg[1], leg[3], 1):
        for x in range(leg[0], leg[2], 1):
            if not close(pxb.getpixel((x,y)), bg2, 50):
                if x < midx: left_pts.append((x,y))
                else: right_pts.append((x,y))
    for name, pts in (("左腿", left_pts), ("右腿", right_pts)):
        if pts:
            ys_ = [p[1] for p in pts]; xs_ = [p[0] for p in pts]
            print(f"  {name}: x范围{min(xs_)}-{max(xs_)} y范围{min(ys_)}-{max(ys_)} 腿高(bbox){max(ys_)-min(ys_)}px 最底点y={max(ys_)} 最高点y={min(ys_)}")
