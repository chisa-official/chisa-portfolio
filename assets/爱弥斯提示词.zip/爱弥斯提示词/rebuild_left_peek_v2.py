# -*- coding: utf-8 -*-
"""left peek 终极修复: 每行独立检测列边界(各行角色位置不同!)"""
import sys, os
sys.path.insert(0, r"D:\trae work\绘制gif动图")
from PIL import Image
import sprite_to_gif as S

SRC = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品精灵图图生图\left peek 精灵图.png"
OUT = r"D:\trae work\绘制gif动图\成品图\爱弥斯成品gif\left peek.gif"
ROW_SPLIT = 2177
DURATION = 250
INSET = 4

im = Image.open(SRC).convert("RGBA")
w, h = im.size

def close(c1, c2, t=45):
    return sum((a-b)**2 for a, b in zip(c1[:3], c2[:3]))**0.5 < t

def col_proj(ya, yb):
    out = []
    for x in range(0, w, 2):
        n = sum(1 for y in range(ya, yb, 4) if not close(im.getpixel((x, y))[:3], (255, 255, 255)))
        out.append(n)
    return out

def smooth(p, win=12):
    return [sum(p[max(0, i-win):min(len(p), i+win+1)])/(min(len(p), i+win+1)-max(0, i-win)) for i in range(len(p))]

def find_col_bounds(ya, yb, expect=4):
    """每行: 找 expect-1 条最宽的近空白列带(内容<阈值)作为分隔线"""
    cp = smooth(col_proj(ya, yb), 10)
    thr = int((yb-ya) * 0.006 / 4)   # 内容量阈值(近空白)
    bands = []
    i = 0
    while i < len(cp):
        if cp[i] <= thr:
            j = i
            while j < len(cp) and cp[j] <= thr:
                j += 1
            bands.append((i*2, j*2))
            i = j
        else:
            i += 1
    # 内部带(排除两侧边缘), 按宽度取 expect-1 条最宽的
    interior = [b for b in bands if b[0] > w*0.02 and b[1] < w*0.98]
    interior.sort(key=lambda b: b[1]-b[0], reverse=True)
    chosen = []
    for b in interior:
        if all(abs((b[0]+b[1])//2 - (c[0]+c[1])//2) >= 80 for c in chosen):
            chosen.append(b)
        if len(chosen) >= expect-1:
            break
    chosen.sort(key=lambda b: b[0])
    if len(chosen) != expect-1:
        print(f"  行{ya}-{yb}: 空白带数 {len(chosen)} != {expect-1}, 带: {chosen}")
        return None
    seps = [(b[0]+b[1])//2 for b in chosen]
    bounds = [(0, seps[0])]
    for i in range(len(seps)-1):
        bounds.append((seps[i], seps[i+1]))
    bounds.append((seps[-1], w))
    return bounds

frames = []
for ri, (ya, yb) in enumerate([(0, ROW_SPLIT), (ROW_SPLIT, h)]):
    bounds = find_col_bounds(ya, yb, 4)
    print(f"行{ri+1} 列边界: {bounds}")
    if not bounds or len(bounds) != 4:
        print("!! 边界数 != 4, 中止")
        sys.exit(1)
    for xa, xb in bounds:
        box = (xa+INSET, ya+INSET, xb-INSET, yb-INSET)
        cell = im.crop(box).copy()
        cell = S.flood_fill_bg(cell, 30)
        frames.append(cell)
print("拆帧:", len(frames))

# 基线对齐(仅垂直)
bboxes = [f.getchannel("A").getbbox() for f in frames]
bottoms = [b[3] for b in bboxes if b]
baseline = max(bottoms)
shifts = [(baseline - b[3]) if b else 0 for b in bboxes]
W = max(f.width for f in frames)
H = max(f.height + s for f, s in zip(frames, shifts))
aligned = []
for f, s in zip(frames, shifts):
    c = Image.new("RGBA", (W, H), (255, 255, 255, 0))
    c.paste(f, (0, s), f)
    aligned.append(c)
print(f"画布 {W}x{H}")

ap = [S.to_gif_frame(f) for f in aligned]
tr = ap[0].info["transparency"]
ap[0].save(OUT, save_all=True, append_images=ap[1:],
           duration=DURATION, loop=0, disposal=2, transparency=tr, optimize=False)
print("已保存:", OUT)

im2 = Image.open(OUT)
for i in range(im2.n_frames):
    im2.seek(i)
    f2 = im2.convert("RGBA")
    a2 = f2.getchannel("A")
    b = a2.getbbox()
    pct = sum(a2.histogram()[128:]) * 100.0 / (a2.size[0]*a2.size[1])
    print(f"  帧{i+1}: 内容占比{pct:.1f}% bbox={b}")
