﻿# 爱弥斯 OCR v3 - ASCII only literals
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

$engine = $null
foreach ($tag in @("zh-Hans-CN", "zh-Hans", "zh-Hant", "zh")) {
    try {
        $l = [Windows.Globalization.Language]::new($tag)
        if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($l)) {
            $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($l)
            if ($engine) { Write-Host "using lang: $tag"; break }
        }
    } catch {}
}
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $engine) { throw "no OCR engine" }

$base = "D:\trae work\绘制gif动图\素材库\爱弥斯"
$files = @(
    "2677b79c82ae5d59861125471e3f4a7a1955897084.jpg",
    "cffa564b6d87216ae1b2fa27b6b6e09f1955897084.jpg",
    "d786704184b2e45c9aea4056347451d41955897084.jpg",
    "77937ad2c60029b80ec58d95fed77bdb1955897084.jpg",
    "7ec88ab9c2bc803bc79748adc45dc7dc1955897084.jpg"
)
$outLines = @()
foreach ($name in $files) {
    $f = Join-Path $base $name
    $stream = $null
    Write-Host "OCR: $name"
    try {
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($f)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $conv = [Windows.Graphics.Imaging.SoftwareBitmap]::Convert($bitmap,
            [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,
            [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied)
        $result = Await ($engine.RecognizeAsync($conv)) ([Windows.Media.Ocr.OcrResult])
        $outLines += "="*70
        $outLines += "FILE: $name"
        $outLines += "LINES: $($result.Lines.Count)"
        $outLines += $result.Text
        $outLines += ""
        Write-Host "  done, lines: $($result.Lines.Count)"
    } catch {
        $outLines += "FILE: $name  OCR_FAILED: $($_.Exception.Message)"
        $outLines += ""
        Write-Host "  failed: $($_.Exception.Message)"
    } finally {
        if ($stream) { $stream.Dispose() }
    }
}
$outLines | Set-Content -Encoding UTF8 "D:\trae work\绘制gif动图\提示词仓库\反推提示词\爱弥斯OCR结果.txt"
Write-Host "OCR ALL DONE"
