# -*- coding: utf-8 -*-
"""
达尼娅 素材图程序化分析 v2 (复用爱弥斯素材分析逻辑, 路径改为达尼娅 Q版表情包)
- 先检测背景色(边缘像素众数),再以背景为参照算内容包围盒
- 逐图:尺寸、背景色、内容bbox、分区域主色、全局调色板、ASCII轮廓
- 跨图统计身份色一致性
- 纯 Pillow,无 numpy;报告直接写 UTF-8 文件
"""
import os, glob, sys
from PIL import Image

FOLDER = r"D:\trae work\绘制gif动图\素材库\达尼娅\二创q版表情包"
OUT = r"D:\trae work\绘制gif动图\提示词仓库\反推提示词\达尼娅素材分析报告.txt"

NAMED = [
    ((0,0,0),"black"), ((255,255,255),"white"), ((128,128,128),"gray"),
    ((255,0,0),"red"), ((200,0,0),"dark red"), ((255,128,128),"light red"),
    ((255,165,0),"orange"), ((255,200,100),"light orange"),
    ((255,255,0),"yellow"), ((250,220,120),"pale yellow"),
    ((144,238,144),"light green"), ((0,180,0),"green"), ((0,90,0),"dark green"),
    ((0,255,255),"cyan"), ((0,180,255),"sky blue"), ((70,130,200),"steel blue"),
    ((0,80,160),"blue"), ((20,40,120),"navy"), ((0,0,255),"pure blue"),
    ((128,0,255),"purple"), ((160,100,255),"light purple"), ((200,180,255),"lavender"),
    ((255,105,180),"pink"), ((255,180,200),"light pink"), ((255,20,147),"deep pink"),
    ((160,82,45),"brown"), ((205,150,110),"tan"), ((255,220,180),"skin/peach"),
    ((230,210,180),"beige"), ((192,192,192),"silver"), ((255,215,0),"gold"),
]
def nearest_name(rgb):
    r,g,b = rgb
    best, bd = "?", 10**9
    for (cr,cg,cb), name in NAMED:
        d = (r-cr)**2+(g-cg)**2+(b-cb)**2
        if d < bd: bd, best = d, name
    return best

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3],c2[:3]))**0.5 < tol

def detect_bg(im):
    """边缘环像素众数 = 背景色"""
    w,h = im.size
    ring = []
    step = 8
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    from collections import Counter
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    bg = tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))
    return bg, len(groups[0]), len(ring)

def dominant(im, box, n=6):
    crop = im.crop(box).convert("RGB")
    w,h = crop.size
    if w<3 or h<3: return []
    q = crop.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(c for c,_ in cnt))
    return [(tuple(pal[idx*3:idx*3+3]), round(c*100.0/tot,1), nearest_name(tuple(pal[idx*3:idx*3+3]))) for c,idx in cnt]

def ascii_art(im, bg, box, W=60, H=28):
    crop = im.crop(box).convert("RGB").resize((W,H))
    px = crop.load()
    chars = " .:-=+*#%@"
    lines = []
    for y in range(H):
        line = ""
        for x in range(W):
            c = px[x,y]
            if close(c, bg, 60): line += " "
            else:
                v = (c[0]+c[1]+c[2])//3
                line += chars[min(9, (255-v)*10//256)]
        lines.append(line)
    return "\n".join(lines)

files = sorted(glob.glob(os.path.join(FOLDER, "*.png")))
buf = []
def P(*a):
    buf.append(" ".join(str(x) for x in a))

P(f"共发现 {len(files)} 张 Q版表情包素材图")

bg_summary = []
per_image = []
for f in files:
    im = Image.open(f)
    if im.mode != "RGBA": im = im.convert("RGBA")
    w,h = im.size
    bg, bgcnt, bgtot = detect_bg(im)
    bgname = nearest_name(bg)
    bg_summary.append(bgname)
    # 内容bbox:与背景差异 > tol
    tol = 45
    minx,miny,maxx,maxy = w,h,-1,-1
    step = 3
    for y in range(0,h,step):
        for x in range(0,w,step):
            if not close(im.getpixel((x,y)), bg, tol):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx < 0: maxx, maxy = w, h
    bbox = (max(0,minx-3), max(0,miny-3), min(w,maxx+3), min(h,maxy+3))
    bw,bh = bbox[2]-bbox[0], bbox[3]-bbox[1]
    P("="*100)
    P(f"文件: {os.path.basename(f)}  尺寸 {w}x{h}")
    P(f"背景: {bgname} rgb{bg} (边缘匹配 {bgcnt}/{bgtot})")
    P(f"内容bbox: {bbox}  内容 {bw}x{bh}  占图 {bw*100//w}% x {bh*100//h}%  宽高比 {bw/bh:.2f}")
    x0,y0,x1,y1 = bbox
    head  = (x0, y0, x1, y0 + int(bh*0.42))
    torso = (x0, y0 + int(bh*0.38), x1, y0 + int(bh*0.80))
    legs  = (x0, y0 + int(bh*0.75), x1, y1)
    P("  [头部区] 主色:", ["%s %s%%"%(n,p) for _,p,n in dominant(im, head)])
    P("  [躯干区] 主色:", ["%s %s%%"%(n,p) for _,p,n in dominant(im, torso)])
    P("  [下肢区] 主色:", ["%s %s%%"%(n,p) for _,p,n in dominant(im, legs)])
    P("  [全局]   主色:", ["%s %s%%"%(n,p) for _,p,n in dominant(im, (0,0,w,h), 8)])
    P("  ASCII轮廓(背景为参照):")
    P(ascii_art(im, bg, bbox))
    per_image.append((os.path.basename(f), bgname, dominant(im, head, 5), dominant(im, torso, 5)))

P("")
P("="*100)
from collections import Counter
P("背景色统计:", dict(Counter(bg_summary)))
# 身份色统计:头部区与躯干区跨图出现频次
P("")
P("跨图头部区主色频次(身份色候选):")
c1 = Counter()
for _,_,hd,_ in per_image:
    for _,p,n in hd:
        if p >= 8: c1[n] += 1
P(sorted(c1.items(), key=lambda x:-x[1]))
P("")
P("跨图躯干区主色频次(身份色候选):")
c2 = Counter()
for _,_,_,tr in per_image:
    for _,p,n in tr:
        if p >= 8: c2[n] += 1
P(sorted(c2.items(), key=lambda x:-x[1]))

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(buf))
print("报告已写入:", OUT)
print("总行数:", len(buf))
