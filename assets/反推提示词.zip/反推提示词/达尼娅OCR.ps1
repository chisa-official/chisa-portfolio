﻿# 达尼娅 OCR v1 - ASCII only literals (复用爱弥斯OCR.ps1 逻辑)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

$engine = $null
foreach ($tag in @("zh-Hans-CN", "zh-Hans", "zh-Hant", "zh")) {
    try {
        $l = [Windows.Globalization.Language]::new($tag)
        if ([Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($l)) {
            $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($l)
            if ($engine) { Write-Host "using lang: $tag"; break }
        }
    } catch {}
}
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $engine) { throw "no OCR engine" }

$base = "D:\trae work\绘制gif动图\素材库\达尼娅"
$files = @(
    "官方设定长图\设定图1.1.jpg",
    "官方设定长图\设定图1.2.jpg",
    "官方设定长图\设定图1.3.jpg",
    "官方设定长图\设定图1.4.jpg",
    "官方设定长图\设定图1.5.jpg",
    "三个提问\64e06f5869c32e638a1432e8cb4f1d101955897084.png",
    "三个提问\c8953acef255e3ec35b9fda19120ad511955897084.png",
    "三个提问\d8a7d3d806d9e0b1fb868a9c957fe8711955897084.png"
)
$outLines = @()
foreach ($name in $files) {
    $f = Join-Path $base $name
    $stream = $null
    Write-Host "OCR: $name"
    try {
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($f)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $conv = [Windows.Graphics.Imaging.SoftwareBitmap]::Convert($bitmap,
            [Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,
            [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied)
        $result = Await ($engine.RecognizeAsync($conv)) ([Windows.Media.Ocr.OcrResult])
        $outLines += "="*70
        $outLines += "FILE: $name"
        $outLines += "LINES: $($result.Lines.Count)"
        $outLines += $result.Text
        $outLines += ""
        Write-Host "  done, lines: $($result.Lines.Count)"
    } catch {
        $outLines += "FILE: $name  OCR_FAILED: $($_.Exception.Message)"
        $outLines += ""
        Write-Host "  failed: $($_.Exception.Message)"
    } finally {
        if ($stream) { $stream.Dispose() }
    }
}
$outLines | Set-Content -Encoding UTF8 "D:\trae work\绘制gif动图\提示词仓库\反推提示词\达尼娅OCR结果.txt"
Write-Host "OCR ALL DONE"

