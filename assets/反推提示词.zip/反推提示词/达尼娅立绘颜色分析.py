# -*- coding: utf-8 -*-
"""
达尼娅 官方立绘 颜色分析 (复用爱弥斯立绘颜色分析逻辑)
处理 官方立绘 目录下所有 JPG/PNG, 输出 UTF-8 报告
"""
import os, glob
from PIL import Image

FOLDER = r"D:\trae work\绘制gif动图\素材库\达尼娅\官方立绘"
OUT = r"D:\trae work\绘制gif动图\提示词仓库\反推提示词\达尼娅立绘颜色报告.txt"

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3],c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    ring = []
    step = max(8, min(w,h)//80)
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    if not groups: return (255,255,255)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

def content_bbox(im, bg, tol=50):
    w,h = im.size
    step = 4
    minx,miny,maxx,maxy = w,h,-1,-1
    for y in range(0,h,step):
        for x in range(0,w,step):
            if not close(im.getpixel((x,y)), bg, tol):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx<0: return (0,0,w,h)
    return (max(0,minx-3), max(0,miny-3), min(w,maxx+3), min(h,maxy+3))

def clusters(im, box, n=6, exclude=None):
    crop = im.crop(box).convert("RGB")
    if crop.size[0] < 4 or crop.size[1] < 4: return []
    q = crop.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(c for c,_ in cnt))
    out = []
    for c,idx in cnt:
        rgb = tuple(pal[idx*3:idx*3+3])
        if exclude and close(rgb, exclude, 25): continue
        out.append((c*100.0/tot, rgb, "#%02X%02X%02X" % rgb))
    return out

files = sorted(glob.glob(os.path.join(FOLDER, "*.jpg")) + glob.glob(os.path.join(FOLDER, "*.png")))
buf = []
def P(*a): buf.append(" ".join(str(x) for x in a))

P(f"立绘文件数: {len(files)}")
for f in files:
    im = Image.open(f).convert("RGB")
    w,h = im.size
    bg = detect_bg(im)
    x0,y0,x1,y1 = content_bbox(im, bg)
    bw,bh = x1-x0, y1-y0
    P("="*80)
    P(f"文件: {os.path.basename(f)}  {w}x{h}  背景rgb{bg}")
    P(f"内容bbox {bw}x{bh} (占图 {bw*100//w}% x {bh*100//h}%)")
    head  = (x0, y0, x1, y0+int(bh*0.30))
    torso = (x0, y0+int(bh*0.25), x1, y0+int(bh*0.70))
    legs  = (x0, y0+int(bh*0.60), x1, y0+int(bh*0.95))
    bottom= (x0, y1-int(bh*0.12), x1, y1)
    P("  [头部区] " + " | ".join(f"{h_} {p:.0f}%" for p,rgb,h_ in clusters(im, head, 5, bg)[:5]))
    P("  [躯干区] " + " | ".join(f"{h_} {p:.0f}%" for p,rgb,h_ in clusters(im, torso, 5, bg)[:5]))
    P("  [下肢区] " + " | ".join(f"{h_} {p:.0f}%" for p,rgb,h_ in clusters(im, legs, 5, bg)[:5]))
    P("  [底部区] " + " | ".join(f"{h_} {p:.0f}%" for p,rgb,h_ in clusters(im, bottom, 4, bg)[:4]))

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(buf))
print("OK", len(buf))
