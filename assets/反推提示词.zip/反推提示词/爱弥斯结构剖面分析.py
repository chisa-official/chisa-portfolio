# -*- coding: utf-8 -*-
"""
爱弥斯 结构剖面分析 v4
- 每行非背景像素宽度剖面 → 头/颈/身比例, 侧发(双马尾)检测
- 头顶色带检测(发饰/头带)
- 眼部精确取色(多候选框)
"""
import os, glob
from PIL import Image

FOLDER = r"D:\trae work\绘制gif动图\素材库\爱弥斯"
OUT = r"D:\trae work\绘制gif动图\提示词仓库\反推提示词\爱弥斯结构剖面报告.txt"

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3],c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    ring = []
    step = 8
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

def content_bbox(im, bg, tol=45):
    w,h = im.size
    step = 3
    minx,miny,maxx,maxy = w,h,-1,-1
    for y in range(0,h,step):
        for x in range(0,w,step):
            if not close(im.getpixel((x,y)), bg, tol):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx<0: return (0,0,w,h)
    return (max(0,minx-3), max(0,miny-3), min(w,maxx+3), min(h,maxy+3))

def row_widths(im, bg, x0,y0,x1,y1, tol=45):
    """每 2% 高度一档,输出该档非背景像素 x 跨度"""
    hh = y1-y0
    spans = []
    for i in range(0, 50):
        ya = y0 + hh*i//50
        yb = y0 + hh*(i+1)//50
        xs = []
        for y in range(ya, yb, 2):
            for x in range(x0, x1, 2):
                if not close(im.getpixel((x,y)), bg, tol):
                    xs.append(x)
        if xs:
            spans.append((i*2, min(xs)-x0, max(xs)-x0, len(set(xs))*2))
        else:
            spans.append((i*2, -1, -1, 0))
    return spans

def band_colors(im, box, n=4):
    crop = im.crop(box).convert("RGB")
    q = crop.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(c for c,_ in cnt))
    return [("#%02X%02X%02X" % tuple(pal[i*3:i*3+3]), round(c*100.0/tot,1)) for c,i in cnt]

def eye_probe(im, bg, head_box):
    """在头部区内多高度扫描眼部候选框,找非肤色深色/蓝色小簇"""
    x0,y0,x1,y1 = head_box
    hh = y1-y0
    res = []
    for frac in (0.30, 0.38, 0.46, 0.54):
        ya = y0 + int(hh*frac); yb = y0 + int(hh*(frac+0.12))
        box = (x0+int((x1-x0)*0.15), ya, x0+int((x1-x0)*0.85), yb)
        res.append((frac, box, band_colors(im, box, 4)))
    return res

files = sorted(glob.glob(os.path.join(FOLDER, "*.png")))
buf = []
def P(*a): buf.append(" ".join(str(x) for x in a))

ratio_est = []
for f in files:
    im = Image.open(f).convert("RGBA")
    bg = detect_bg(im)
    x0,y0,x1,y1 = content_bbox(im, bg)
    bw,bh = x1-x0, y1-y0
    spans = row_widths(im, bg, x0,y0,x1,y1)
    # 找头部结束:头部宽度(前 20% 高度平均宽) → 之后第一个明显收窄(颈)
    head_w = max(s[3] for s in spans[:12])
    neck_row = None
    body_max = 0
    for pct, l, r, wd in spans[10:]:
        if wd > 0 and wd < head_w*0.75:
            neck_row = pct; break
    # 身体最大宽(头部之后)
    body_max = max((s[3] for s in spans if s[0]>=20), default=0)
    # 底部宽(脚/裙摆)
    bottom_w = spans[-1][3] if spans else 0
    # 侧发检测:头部下方 20%-45% 高度处,左右边缘是否都有非背景像素且远离中心(宽 > 身体宽)
    side_check = spans[10:24]
    side_w = max((s[3] for s in side_check), default=0)
    head_frac = (spans and max(s[0] for s in spans[:14] if s[3] >= head_w*0.9)) or 0
    P("="*78)
    P(os.path.basename(f))
    P(f"  bbox {bw}x{bh}  头部宽~{head_w}px  身体最大宽~{body_max}px  底部宽~{bottom_w}px  颈缩行~{neck_row}%")
    P(f"  头占高度~{head_frac}%  (头部结束百分比)")
    # 头顶色带(头顶 0-8% 高度)
    band = band_colors(im, (x0, y0, x1, y0+int(bh*0.08)), 4)
    P("  头顶色带:", band)
    # 眼部扫描
    for frac, box, cols in eye_probe(im, bg, (x0,y0,x1,y0+int(bh*0.5))):
        dark = [c for c in cols if c[1]>8]
        P(f"  眼框@{frac:.2f}: {dark}")
    ratio_est.append(head_frac)

P("")
P("="*78)
P("头部结束高度百分比(全图):", ratio_est)
P("均值(头身比参考):", sum(ratio_est)/len(ratio_est))

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(buf))
print("OK", len(buf), "lines")
