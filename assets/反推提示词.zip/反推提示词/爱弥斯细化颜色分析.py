# -*- coding: utf-8 -*-
"""
爱弥斯 细化颜色分析 v3
- 头部区(发色)、眼部区、躯干区、鞋靴区 的精确 RGB/hex 主色
- 跨图统计身份色的精确 RGB 范围
- 发色渐变检查:头顶 vs 发梢
"""
import os, glob
from PIL import Image

FOLDER = r"D:\trae work\绘制gif动图\素材库\爱弥斯"
OUT = r"D:\trae work\绘制gif动图\提示词仓库\反推提示词\爱弥斯细化颜色报告.txt"

def close(c1, c2, tol=40):
    return sum((a-b)**2 for a,b in zip(c1[:3],c2[:3]))**0.5 < tol

def detect_bg(im):
    w,h = im.size
    ring = []
    step = 8
    for x in range(0,w,step):
        ring += [im.getpixel((x,0))[:3], im.getpixel((x,h-1))[:3]]
    for y in range(0,h,step):
        ring += [im.getpixel((0,y))[:3], im.getpixel((w-1,y))[:3]]
    groups = []
    for c in ring:
        for g in groups:
            if close(g[0], c, 30):
                g.append(c); break
        else:
            groups.append([c])
    groups.sort(key=len, reverse=True)
    return tuple(sum(c[i] for c in groups[0])//len(groups[0]) for i in range(3))

def content_bbox(im, bg, tol=45):
    w,h = im.size
    step = 3
    minx,miny,maxx,maxy = w,h,-1,-1
    for y in range(0,h,step):
        for x in range(0,w,step):
            if not close(im.getpixel((x,y)), bg, tol):
                if x<minx: minx=x
                if x>maxx: maxx=x
                if y<miny: miny=y
                if y>maxy: maxy=y
    if maxx<0: return (0,0,w,h)
    return (max(0,minx-3), max(0,miny-3), min(w,maxx+3), min(h,maxy+3))

def clusters(im, box, n=5, exclude=None):
    """返回区域主色簇: [(hex, rgb, 百分比), ...] exclude=(bg) 排除背景"""
    crop = im.crop(box).convert("RGB")
    q = crop.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(c for c,_ in cnt))
    out = []
    for c,idx in cnt:
        rgb = tuple(pal[idx*3:idx*3+3])
        if exclude and close(rgb, exclude, 25): continue
        out.append((c*100.0/tot, rgb, "#%02X%02X%02X" % rgb))
    return out

files = sorted(glob.glob(os.path.join(FOLDER, "*.png")))
buf = []
def P(*a): buf.append(" ".join(str(x) for x in a))

head_colors = []   # (hex, rgb, pct)
eye_colors = []
torso_colors = []
shoe_colors = []
hair_top = []
hair_bottom = []

for f in files:
    im = Image.open(f).convert("RGBA")
    w,h = im.size
    bg = detect_bg(im)
    x0,y0,x1,y1 = content_bbox(im, bg)
    bw,bh = x1-x0, y1-y0
    # 头部区(发色): 内容区顶部 45%
    head = (x0, y0, x1, y0+int(bh*0.45))
    # 眼部区: 头部区内 35%-65% 高度, 中央 60% 宽度
    hx0,hy0,hx1,hy1 = head
    eye = (hx0+int((hx1-hx0)*0.2), hy0+int((hy1-hy0)*0.35), hx0+int((hx1-hx0)*0.8), hy0+int((hy1-hy0)*0.65))
    # 躯干: 45%-80%
    torso = (x0, y0+int(bh*0.45), x1, y0+int(bh*0.80))
    # 鞋靴: 底部 12%
    shoe = (x0, y1-int(bh*0.12), x1, y1)
    # 发顶 vs 发梢: 头部区上 40% vs 下 40%
    top_h = (x0, y0, x1, y0+int(bh*0.18))
    bot_h = (x0, y0+int(bh*0.30), x1, y0+int(bh*0.45))

    hc = clusters(im, head, 5, bg)
    ec = clusters(im, eye, 4, bg)
    tc = clusters(im, torso, 5, bg)
    sc = clusters(im, shoe, 4, bg)
    tp = clusters(im, top_h, 3, bg)
    bp = clusters(im, bot_h, 3, bg)

    P("="*80)
    P(os.path.basename(f))
    P("  头部(发色): " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in hc[:4]))
    P("  眼部区:     " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in ec[:3]))
    P("  躯干(服饰): " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in tc[:4]))
    P("  底部(鞋靴): " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in sc[:3]))
    P("  发顶区:     " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in tp[:3]))
    P("  发梢区:     " + " | ".join(f"{hex_} {p:.0f}%" for p,rgb,hex_ in bp[:3]))

    head_colors += [(hex_,rgb,p) for p,rgb,hex_ in hc[:3]]
    eye_colors  += [(hex_,rgb,p) for p,rgb,hex_ in ec[:2]]
    torso_colors+= [(hex_,rgb,p) for p,rgb,hex_ in tc[:3]]
    shoe_colors += [(hex_,rgb,p) for p,rgb,hex_ in sc[:2]]
    hair_top    += [(hex_,rgb,p) for p,rgb,hex_ in tp[:2]]
    hair_bottom += [(hex_,rgb,p) for p,rgb,hex_ in bp[:2]]

def summarize(name, data, topn=8):
    # 按 rgb 聚类合并
    groups = []
    for hex_,rgb,p in data:
        for g in groups:
            if close(g[0][1], rgb, 45):
                g.append((hex_,rgb,p)); break
        else:
            groups.append([(hex_,rgb,p)])
    groups.sort(key=lambda g: sum(x[2] for x in g), reverse=True)
    P(f"\n跨图{name}聚类(top{topn}):")
    for g in groups[:topn]:
        tot = sum(x[2] for x in g)
        r = sum(x[1][0] for x in g)//len(g); gg = sum(x[1][1] for x in g)//len(g); b = sum(x[1][2] for x in g)//len(g)
        P(f"  rgb({r},{gg},{b}) #{r:02X}{gg:02X}{b:02X}  样本{len(g)} 加权占比{tot:.0f}%  例: {g[0][0]}")

summarize("头部(发色)", head_colors)
summarize("眼部", eye_colors)
summarize("躯干(服饰)", torso_colors)
summarize("底部(鞋靴)", shoe_colors)
summarize("发顶", hair_top)
summarize("发梢", hair_bottom)

with open(OUT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(buf))
print("OK 写入", OUT, "行数", len(buf))
