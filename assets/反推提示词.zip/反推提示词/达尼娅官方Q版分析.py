# -*- coding: utf-8 -*-
"""官方q版图.png 精细化分析: 发型轮廓/分区/瞳色/发饰/服饰色 """
from PIL import Image

SRC = r"D:\trae work\绘制gif动图\素材库\达尼娅\官方立绘\官方q版图.png"
im = Image.open(SRC).convert("RGBA")
w, h = im.size
print("尺寸:", im.size)

def close(c1, c2, t=45):
    return sum((a-b)**2 for a,b in zip(c1[:3],c2[:3]))**0.5 < t

BG = (0, 0, 0)  # 黑底
px = im.load()

# 内容bbox
minx,miny,maxx,maxy = w,h,-1,-1
for y in range(0,h,2):
    for x in range(0,w,2):
        if not close(px[x,y][:3], BG, 40):
            if x<minx: minx=x
            if x>maxx: maxx=x
            if y<miny: miny=y
            if y>maxy: maxy=y
print("内容bbox:", (minx,miny,maxx,maxy))
bw,bh = maxx-minx, maxy-miny

# ASCII 轮廓 (彩色分类)
def cls(r,g,b):
    if close((r,g,b), (0,0,0), 60): return " "      # 黑背景
    if r>235 and g>235 and b>235: return "W"          # 白
    if b>r+25 and b>120 and g>80 and b>g-40: return "B"  # 蓝/紫(亮)
    if r>180 and b>150 and g>100 and abs(r-b)<70: return "V"  # 紫粉/薰衣草
    if r>200 and g>140 and g<190 and b>150 and b<230: return "v"  # 淡紫
    if r>220 and g>170 and b>170: return "p"          # 粉
    if r>110 and g>60 and b>110 and b>=r: return "P"  # 深紫
    if r>140 and g>110 and b>110 and r>b: return "s"  # 肤色
    if r>200 and g>170 and b<150: return "g"          # 金黄
    return "#"                                          # 深色

# 全图 ASCII (80x36)
crop = im.crop((minx,miny,maxx,maxy)).resize((80,36))
cp = crop.load()
print("--- ASCII 全图(黑底) ---")
for y in range(36):
    line = ""
    for x in range(80):
        r,g,b = cp[x,y][:3]
        line += cls(r,g,b)
    print(line)

# 分区主色(内容bbox内)
def dom(box, n=6):
    c = im.crop(box).convert("RGB")
    q = c.quantize(colors=n)
    pal = q.getpalette()
    cnt = sorted(q.getcolors(), reverse=True)
    tot = max(1, sum(x for x,_ in cnt))
    return [("#%02X%02X%02X" % tuple(pal[i*3:i*3+3]), round(cn*100.0/tot,1)) for cn,i in cnt]

x0,y0,x1,y1 = minx,miny,maxx,maxy
head = (x0, y0, x1, y0+int(bh*0.42))
torso = (x0, y0+int(bh*0.38), x1, y0+int(bh*0.80))
legs = (x0, y0+int(bh*0.75), x1, y1)
print("\n头部区主色:", dom(head))
print("躯干区主色:", dom(torso))
print("下肢区主色:", dom(legs))

# 眼部: 头部区下部
eye = (x0+int(bw*0.25), y0+int(bh*0.22), x0+int(bw*0.75), y0+int(bh*0.40))
print("眼部区主色:", dom(eye, 5))

# 发顶/发梢
top = (x0, y0, x1, y0+int(bh*0.12))
bot = (x0, y0+int(bh*0.30), x1, y0+int(bh*0.45))
print("发顶区主色:", dom(top, 4))
print("发梢区主色:", dom(bot, 4))

# 每 5% 高度行宽剖面(看发型轮廓: 头宽/肩宽/裙摆)
print("\n行宽剖面(每5%高度):")
for i in range(0, 20):
    ya = y0 + bh*i//20
    yb = y0 + bh*(i+1)//20
    xs = []
    for y in range(ya, yb, 2):
        for x in range(x0, x1, 2):
            if not close(px[x,y][:3], BG, 40):
                xs.append(x)
    if xs:
        print(f"  {i*5:2d}-{i*5+5:2d}%: 宽{max(xs)-min(xs)}px  x[{min(xs)}-{max(xs)}]")
    else:
        print(f"  {i*5:2d}-{i*5+5:2d}%: 空")
